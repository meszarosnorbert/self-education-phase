document.addEventListener("DOMContentLoaded", () => {
    const container = document.querySelector("#container");

    // Post kérése { method: "GET"}
    fetch("https://jsonplaceholder.typicode.com/posts/1")
        .then((response) => response.json())
        .then((json) => {
            console.log(json);
            container.innerHTML += `
                <section id="get-method" class="tile">
                    <p>Adat kerese { method: "GET"}</p>
                    <p>userId: ${json["userId"]}</p>
                    <p>id: ${json["id"]}</p>
                    <p>title: ${json["title"]}</p>
                    <p>body: ${json["body"]}</p>
                </section>`;
        });

    // POST létrehozása vagy POST updatelése

    let data = {
        id: Math.random() > 0.5 ? "22" : "",
        userId: "42",
        title: "idezet",
        body: "'Az iskolázatlan ember számára igen jó dolog az idézetgyűjtemények olvasása.' Winston Churchill",
    };

    fetch(
        data["id"]
            ? `https://jsonplaceholder.typicode.com/posts/${data["id"]}`
            : "https://jsonplaceholder.typicode.com/posts/",
        {
            method: data["id"] ? "PUT" : "POST",
            body: JSON.stringify({
                id: data["id"] ? data["id"] : "",
                userId: data["userId"],
                title: data["title"],
                body: data["body"],
            }),
            headers: {
                "Content-type": "application/json; charset=UTF-8",
            },
        }
    )
        .then((response) => response.json())
        .then((json) => {
            container.innerHTML += `
                <section id="post-method" class="tile">
                    <p>Adat letrehozas { method: ${
                        data["id"] ? "PUT" : "POST"
                    }}</p>
                    <p>userId: ${json["userId"]}</p>
                    <p>id: ${json["id"]}</p>
                    <p>title: ${json["title"]}</p>
                    <p>body: ${json["body"]}</p>
                </section>`;
        });

    // első 10 POST ["title"] kiírás, ajánlott --> filter() és map()
    fetch("https://jsonplaceholder.typicode.com/posts/")
        .then((response) => response.json())
        .then((jsonArray) => {
            let filter = jsonArray.filter((json) => json["id"] < 10);
            filter.forEach((element) => {
                container.innerHTML += `
                <section id="filter-method" class="tile">
                    <p>Adat szurese { filter , map}</p>
                    <p>id: ${element["id"]}</p>
                    <p>title: ${element["title"]}</p>
                </section>`;
            });
        });

    // POST törlése
    for (let index = 99; index > 98; index--) {
        fetch(`https://jsonplaceholder.typicode.com/posts/${index}`, {
            method: "DELETE",
        })
            .then((response) => response.json())
            .then((json) => {
                container.innerHTML += `
                <section id="delete-method" class="tile">
                <p>Adat kerese { method: "DELETE"}</p>
                <p>userId: ${json["userId"]}</p>
                <p>id: ${json["id"]}</p>
                <p>title: ${json["title"]}</p>
                <p>body: ${json["body"]}</p>
            </section>
            `;
            });
    }

    // lancolas CREATE --> UPDATE --> DELETE

    // async-await lancolas CREATE --> UPDATE --> DELETE
});
