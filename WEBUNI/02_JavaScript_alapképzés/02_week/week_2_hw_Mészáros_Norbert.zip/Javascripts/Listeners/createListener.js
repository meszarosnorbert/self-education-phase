// input change eseményre létrehoz  + listeners
import { setData } from "../data.js";

export const createItem = (dataSet) => {
    document.querySelector("#input-text").addEventListener("change", (l) => {
        let newData = {
            task: l.target.value,
            isCompleted: false,
            taskDifficult: parseInt(document.querySelector("#number").value),
        };
        dataSet.unshift(newData);
        setData(dataSet);
        l.target.value = "";
    });
};
