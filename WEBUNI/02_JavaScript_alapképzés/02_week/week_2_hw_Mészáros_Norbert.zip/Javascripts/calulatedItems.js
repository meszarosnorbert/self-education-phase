export const percent = (dataSet) => {
    let calculateProgess = 0;

    dataSet.forEach((data) => {
        if (data.isCompleted) {
            calculateProgess++;
        }
    });

    document.querySelector("#completedPercentage").textContent = `${Math.round(
        (calculateProgess / dataSet.length) * 100
    )}`;

    /*
    // Valahogy nem tudom működésre bírni, Mi lehet a hiba?
        //function test(dataSet)
        //​length: 1
​        //name: "test"
​        //<prototype>: function ()

    let test = (dataSet) => {
        dataSet.filter((d) => {
            d.isCompleted == false;
        }).length;
    };

    console.log(test);
    */
};

//lopott részlet a megoldásból
export const hardestItem = (dataSet) => {
    let hardestItem = Math.max(...dataSet.map((t) => t.taskDifficult));
    document.querySelector("#hardest").textContent = hardestItem;
    document.querySelector("#hardest-task").textContent = dataSet.find(
        (t) => t.taskDifficult === hardestItem
    ).task;
};
